# ETHRION v2.5 Full Bundle
이 패키지는 ETHRION 사이트의 완전 버전입니다.
## 설치 방법
1. GitHub Pages 리포지토리로 이동
2. "Upload files" 클릭 → 이 ZIP을 업로드 후 Commit
3. 30초 후 https://ethrion.tech 접속
4. Cloudflare 사용 시 캐시를 Purge Everything

포함: index.html, 서브페이지 4종, style.css, script.js, og.png, sitemap.xml
